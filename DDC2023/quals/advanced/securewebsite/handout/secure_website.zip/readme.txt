## Docker setup

build and run with

docker build -t secweb .
docker run -p 8000:8000 --name secure_website secweb

then access at 127.0.0.1:8000


Good luck :)